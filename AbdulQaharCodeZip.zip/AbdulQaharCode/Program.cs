﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AbdulQaharCode
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[] chars = { 'l','m', 'o','p' };
            Console.WriteLine($"{ FunnyString(chars) }");// Question one
            int[] ints = { 1, 2, 3, 4, 5, 10, 11, 13 };
            Console.WriteLine(ToyFunction(ints));//Question two
        }
        static string FunnyString(char[] chars)
        {
            for (int i = 0; i < chars.Length-1; i--)
            {
                List<char> newChar = new List<char>();
                newChar.Add(chars[i]);
                
                byte[] acc1 = Encoding.ASCII.GetBytes(chars);
                byte[] acc2 = Encoding.ASCII.GetBytes(newChar.ToArray());
                foreach(char c in acc1)
                {
                    decimal d = (decimal)c;
                    foreach(char c2 in acc2)
                    {
                        decimal e = (decimal)c2;
                        if (Math.Abs(d) == Math.Abs(e) )
                        {
                            return " Funny String";
                        }

                    }
                }
                
                 
            }
            return "  Not Funny String";
        }
        static int ToyFunction(int[] weights)
        {
            int container = 1;
            
            for (int i = 0; i < weights.Length-1; i++)
            {
                if (weights[i] < weights[i + 4])
                {
                    List<int> newweights = new List<int>();
                    newweights.Add(weights[i]);
                    container++;
                }
                break;
                
            }
            return container;
        }
    }
}
