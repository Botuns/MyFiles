﻿using System;

namespace OLAJIDE_CODE_CHALLENGE
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Question one
            int[] num = { 1, 3, 5, 6, };
            Console.WriteLine($"{num[0]},{num[1]}, {num[2]},{num[3]}");
            Console.WriteLine("Enter your target number");
            int tag = int.Parse(Console.ReadLine());
            for (int i = 0; i > num.Length;)
            {
                if (num[i] == tag)
                {
                    Console.WriteLine($"Your target at is at an index {i} ");

                }
                if (num[i] + 1 == tag)
                {
                    Console.WriteLine($"Your target  is at an index {i + 1}");
                }




            }


            int[] num1 = { 1, 3 };
            int[] num2 = { 2 };
            int[] mArray = { 1, 2, 3 };
         //   for (int i = 0; i < mArray.Length; i++)
            
                Console.WriteLine($"The median is {mArray[1]} ");
            int[]b = {1,2,3,4};
            int med = (b[1] + b[2])/2;
            
            Console.WriteLine($"The median is {med} ");

            //Question three
            string[] record = { "A", "L", "P" };
           // bool t = false;
            for (int i = 0; i < record.Length; i++)
            {
                Console.WriteLine("Enter a student record for a week");
                Console.WriteLine("A-absent\nL-late\nP-present");
                string stud1 = Console.ReadLine();
                string stud2 = Console.ReadLine();
                string stud3 = Console.ReadLine();
                string stud4 = Console.ReadLine();
                string stud5 = Console.ReadLine();
               
            }



			}

			
			
			
    }
}
