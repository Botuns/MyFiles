﻿using System;

namespace BLAZE_BANK_APP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.ShowMainMenu();
        }
    }
}
