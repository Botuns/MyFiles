﻿using System;
using System.Collections;


namespace BLAZE_BANK_APP
{
    public class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.ShowMainMenu();
        }
    }
}
